import DinoGame from "@/components/dino/DinoGame";

const DinoPage = () => <DinoGame />;

export default DinoPage;
