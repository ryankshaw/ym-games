import BasketballGame from "@/components/game/BasketballGame";

const BasketballPage = () => <BasketballGame />;

export default BasketballPage;
