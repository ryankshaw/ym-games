import BullGame from "@/components/bull/BullGame";

const BullPage = () => <BullGame />;

export default BullPage;
