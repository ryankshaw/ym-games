import SoccerGame from "@/components/soccer/SoccerGame";

const SoccerPage = () => <SoccerGame />;

export default SoccerPage;
