import Game3D from "@/components/Game3D";

const Index = () => {
  return <Game3D />;
};

export default Index;
