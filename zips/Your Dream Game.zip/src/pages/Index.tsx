import GameCanvas from '@/components/game/GameCanvas';

const Index = () => <GameCanvas />;

export default Index;
